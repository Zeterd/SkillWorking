# Trabalh de Teoria de Informaçao

## Objetivo

Fazer dois programas em python para comprimir e descomprimir usando o algoritmo Lempel-Ziv ensinado nas aulas

## Desenvlvido por

Jose Pedro Sousa 201503443

## Execuçao do codigo

### Comprimir
    $ timer python compress.py <ficheiro.txt> <ficheiro.lz>
    
### Descomprimir
    $ timer python decompress.py <ficheiro.lz> <ficheiro_2.txt>
    
## Outros Assuntos

Em ambos os codigos nao têm o algoritmo de otimizaçao de ir tiranto do dicionario as palavras que ja nao sao precisas

O tempo maximo de execuçao foi de 3 min e 56 sec, no comprimir

Em descomprimir demorou cerca de 1 min 52 sec

Testes feitos pelo ficheiro que o professor forneceu de ~530kB
